const {

  ContainerBuilder,

  TextDisplayBuilder,

  SeparatorBuilder,

  SeparatorSpacingSize,

  StringSelectMenuBuilder,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  MessageFlags,

  ComponentType

} = require("discord.js");

const categories = {

  playback: {

    emoji: "<:music:1439124312358653952>",

    name: "Music Playback",

    commands: [

      "!play <song> — Play or queue a track",

      "!join — Join a VC",

      "!pause — Pause the current song",

      "!resume — Resume playback",

      "!skip — Skip current track",

      "!back — Play previous track",

      "!stop — Stop music and clear queue",

      "!disconnect — Leave the voice channel",

      "!nowplaying — Show current song info",

      "!forward — Jump forward in a song",

      "!backward — Rewind the song"

    ]

  },

  queue: {

    emoji: "<:playlist:1439118111780507658>",

    name: "Queue Management",

    commands: [

      "!queue — View queue list",

      "!shuffle — Shuffle the queue",

      "!clear — Clear the queue",

      "!remove — Remove a specific track",

      "!move — Move a song in queue"

    ]

  },

  playlists: {

    emoji: "<:spotify:1439105086797250631>",

    name: "Playlists",

    commands: [

      "!pl create — Create a playlist",

      "!pl save — Save current queue",

      "!pl load — Load a playlist",

      "!pl append — Add songs to queue",

      "!pl list — List your playlists",

      "!pl delete — Delete a playlist",

      "!pl rename — Rename a playlist",

      "!pl share — Share playlist link",

      "!pl import — Import Spotify playlist"

    ]

  },

  filters: {

    emoji: "<:filters:1439118976612307026>",

    name: "Audio Filters",

    commands: [

      "!filter — Apply filters",

      "!loop — Enable repeat mode",

      "!autoplay — Auto-continue songs",

      "!volume — Change volume",

      "!seek — Jump to specific time"

    ]

  },

  premium: {

    emoji: "<a:premium:1439107157915205645>",

    name: "Premium",

    commands: [

      "!premium-redeem — Redeem premium code",

      "!premium-activate — Activate premium plan",

      "!premium-enable — Enable premium in server",

      "!premium-disable — Disable premium",

      "!premium-status — Check your premium status",

      "!premium-benefits — Show your premium benefits"

    ]

  },

  info: {

    emoji: "<:Info:1439119470634471445>",

    name: "Information",

    commands: [

      "!lyrics — Show lyrics",

      "!ping — Check bot latency",

      "!stats — Bot system statistics",

      "!setprefix <prefix> — Change bot prefix",

      "!help — Show help menu"

    ]

  }

};

// Create main container

function createHelpContainer(selectedCategory = null) {

  const container = new ContainerBuilder();

  container.addTextDisplayComponents(

    new TextDisplayBuilder().setContent(`### <:emoji_55:1436261993827926118> Nexo — Help Menu`)

  );

  container.addSeparatorComponents(

    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)

  );

  container.addTextDisplayComponents(

    new TextDisplayBuilder().setContent(

      ` Prefix: \`!\`  •  Type: Music & Premium System\n\n`

    )

  );

  container.addSeparatorComponents(

    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)

  );

  if (!selectedCategory) {

    const catList = Object.entries(categories)

      .map(([_, cat]) => `${cat.emoji} **${cat.name}**`)

      .join("\n");

    container.addTextDisplayComponents(

      new TextDisplayBuilder().setContent(catList)

    );

  } else {

    const cat = categories[selectedCategory];

    if (cat) {

      const cmdList = cat.commands.map(c => `> ${c}`).join("\n");

      container.addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `## ${cat.emoji} ${cat.name}\n${cmdList}`

        )

      );

    } else {

      container.addTextDisplayComponents(

        new TextDisplayBuilder().setContent("⚠️ Invalid category selected.")

      );

    }

  }

  container.addSeparatorComponents(

    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)

  );

  container.addTextDisplayComponents(

    new TextDisplayBuilder().setContent(`Developed with 💙 by Team Nexo`)

  );

  return container;

}

// Dropdown menu builder

function createSelectMenu(currentCategory = null) {

  const select = new StringSelectMenuBuilder()

    .setCustomId("help_select")

    .setPlaceholder("Select a Category");

  select.addOptions({

    label: "Home",

    value: "home",

    description: "Back to main help menu",

    default: currentCategory === null

  });

  for (const [key, cat] of Object.entries(categories)) {

    select.addOptions({

      label: cat.name,

      value: key,

      description: `${cat.commands.length} commands`,

      default: currentCategory === key

    });

  }

  return new ActionRowBuilder().addComponents(select);

}

// Buttons row builder

function createButtonsRow(includeBack = false) {

  const row = new ActionRowBuilder().addComponents(

    new ButtonBuilder()

      .setCustomId("help_all")

      .setLabel(" View All Commands")

      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()

      .setCustomId("help_stats")

      .setLabel(" View Bot Stats")

      .setStyle(ButtonStyle.Primary)

  );

  if (includeBack) {

    row.addComponents(

      new ButtonBuilder()

        .setCustomId("help_back")

        .setLabel(" Back to Home")

        .setStyle(ButtonStyle.Secondary)

    );

  }

  return row;

}

module.exports = {

  name: "help",

  description: "Shows all commands and bot info",

  async execute(message) {

    const baseContainer = createHelpContainer();

    const selectMenu = createSelectMenu();

    const buttons = createButtonsRow();

    baseContainer.addActionRowComponents(selectMenu);

    baseContainer.addActionRowComponents(buttons);

    const sent = await message.reply({

      components: [baseContainer],

      flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2,

      fetchReply: true

    });

    const collector = sent.createMessageComponentCollector({

      time: 0

    });

    collector.on("collect", async interaction => {

      if (interaction.user.id !== message.author.id)

        return interaction.reply({

          content: "❌ Only you can use this menu.",

          ephemeral: true

        });

      // Dropdown category selection

      if (interaction.isStringSelectMenu()) {

        const value = interaction.values[0];

        const category = value === "home" ? null : value;

        const newContainer = createHelpContainer(category);

        newContainer.addActionRowComponents(createSelectMenu(category));

        newContainer.addActionRowComponents(createButtonsRow());

        await interaction.update({

          components: [newContainer],

          flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

        });

      }

      // Button events

      if (interaction.isButton()) {

        const id = interaction.customId;

        // 📜 View All Commands

        if (id === "help_all") {

          const allContainer = new ContainerBuilder()

            .addTextDisplayComponents(

              new TextDisplayBuilder().setContent(`** Nexo Full Command List**`)

            )

            .addSeparatorComponents(new SeparatorBuilder().setDivider(true));

          for (const cat of Object.values(categories)) {

            allContainer.addTextDisplayComponents(

              new TextDisplayBuilder().setContent(

                `**${cat.emoji} ${cat.name}**\n${cat.commands

                  .map(c => `> ${c}`)

                  .join("\n")}\n`

              )

            );

            allContainer.addSeparatorComponents(

              new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)

            );

          }

          allContainer.addTextDisplayComponents(

            new TextDisplayBuilder().setContent(`Developed with 💙 by Team Nexo`)

          );

          allContainer.addActionRowComponents(createButtonsRow(true)); // add back button

          await interaction.update({

            components: [allContainer],

            flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

          });

        }

        // 📊 View Bot Stats

        if (id === "help_stats") {

          const { client } = message;

          const uptime = Math.floor(client.uptime / 1000);

          const days = Math.floor(uptime / 86400);

          const hours = Math.floor((uptime % 86400) / 3600);

          const minutes = Math.floor((uptime % 3600) / 60);

          const seconds = uptime % 60;

          const statContainer = new ContainerBuilder()

            .addTextDisplayComponents(

              new TextDisplayBuilder().setContent(` __**GlimpZ Bot Statistics**__`)

            )

            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

            .addTextDisplayComponents(

              new TextDisplayBuilder().setContent(

                `**Servers:** ${client.guilds.cache.size}\n` +

                  `**Users:** ${client.guilds.cache.reduce(

                    (a, g) => a + g.memberCount,

                    0

                  )}\n` +

                  `**Channels:** ${client.channels.cache.size}\n` +

                  `**Uptime:** ${days}d ${hours}h ${minutes}m ${seconds}s`

              )

            )

            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

            .addTextDisplayComponents(

              new TextDisplayBuilder().setContent(`Developed with 💙 by Team Nexo`)

            )

            .addActionRowComponents(createButtonsRow(true)); // add back button

          await interaction.update({

            components: [statContainer],

            flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

          });

        }

        // ⬅️ Back to Home

        if (id === "help_back") {

          const homeContainer = createHelpContainer();

          homeContainer.addActionRowComponents(createSelectMenu());

          homeContainer.addActionRowComponents(createButtonsRow());

          await interaction.update({

            components: [homeContainer],

            flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

          });

        }

      }

    });

  }

};