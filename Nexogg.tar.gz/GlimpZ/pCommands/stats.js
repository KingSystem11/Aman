const {

  ContainerBuilder,

  TextDisplayBuilder,

  SeparatorBuilder,

  SeparatorSpacingSize,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  MessageFlags

} = require("discord.js");

module.exports = {

  name: "stats",

  description: "Displays GlimpZ advanced system statistics",

  aliases: ["statistics", "botinfo"],

  async execute(message) {

    const { client } = message;

    // 🧮 Core Stats

    const totalGuilds = client.guilds.cache.size;

    const totalUsers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

    const totalChannels = client.channels.cache.size;

    // ⏱️ Uptime

    const uptime = Math.floor(client.uptime / 1000);

    const days = Math.floor(uptime / 86400);

    const hours = Math.floor((uptime % 86400) / 3600);

    const minutes = Math.floor((uptime % 3600) / 60);

    const seconds = uptime % 60;

    const uptimeString = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    // 🧠 Resources

    const memory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

    const wsLatency = client.ws.ping;

    const nodes = client.poru?.nodes?.size || 0;

    const activePlayers = client.poru?.players?.size || 0;

    // 🟩 Dynamic Health Indicator

    const latencyHealth =

      wsLatency < 80 ? "<a:GreenDot:1438002543325085746> Excellent" : wsLatency < 150 ? "<a:yellow_dot:1438002750297210979> Stable" : "<a:RedDot:1438002450085707846> High";

    // 🧩 Container

    const container = new ContainerBuilder()

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(`#  GlimpZ — System Status Dashboard`)

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:emoji_54:1435581730114375683> **Bot Identity**\n` +

            `<:emoji_54:1435581730114375683> Username: **${client.user.username}**\n` +

            `<:emoji_54:1435581730114375683> ID: \`${client.user.id}\`\n` +

            `<:emoji_54:1435581730114375683> Version: GlimpZ v3.5`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          ` **Network Overview**\n` +

            `<:emoji_54:1435581730114375683> Servers: \`${totalGuilds}\`\n` +

            `<:emoji_54:1435581730114375683> Users: \`${totalUsers.toLocaleString()}\`\n` +

            `<:emoji_54:1435581730114375683> Channels: \`${totalChannels}\`\n` +

            `<:emoji_54:1435581730114375683> Uptime: \`${uptimeString}\``

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          ` **Music Engine**\n` +

            `<:emoji_54:1435581730114375683> Active Players: \`${activePlayers}\`\n` +

            `<:emoji_54:1435581730114375683> Lavalink Nodes: \`${nodes}\`\n` +

            `<:emoji_54:1435581730114375683> Engine Health: **${latencyHealth}**`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          ` **System Resources**\n` +

            `<:emoji_54:1435581730114375683> Memory Usage: \`${memory} MB\`\n` +

            `<:emoji_54:1435581730114375683> Websocket Latency: \`${wsLatency}ms\`\n` +

            `<:emoji_54:1435581730114375683> Node.js: \`${process.version}\`\n` +

            `<:emoji_54:1435581730114375683> Container Runtime: **Stable**`

        )

      )

      .addSeparatorComponents(

        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)

      )

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:emoji_54:1435581730114375683> *Developed with 💙 by Team ClouDz*\n` +

            `<:emoji_54:1435581730114375683> *Engineered by KingSystem11*`

        )

      );

    // 🧩 Buttons

    const buttonRow = new ActionRowBuilder().addComponents(

      new ButtonBuilder()

        .setLabel(" Refresh Stats")

        .setCustomId("refresh_stats")

        .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()

        .setLabel(" Back to About")

        .setCustomId("back_about")

        .setStyle(ButtonStyle.Primary)

    );

    container.addActionRowComponents(buttonRow);

    const sent = await message.reply({

      components: [container],

      flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2,

      fetchReply: true

    });

    // 🔁 Refresh Handler

    const collector = sent.createMessageComponentCollector({ time: 0 });

    collector.on("collect", async (interaction) => {

      if (interaction.user.id !== message.author.id)

        return interaction.reply({

          content: "❌ Only you can interact with this dashboard.",

          ephemeral: true

        });

      if (interaction.customId === "refresh_stats") {

        const newMemory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

        const newPing = client.ws.ping;

        const newHealth =

          newPing < 80 ? "<a:GreenDot:1438002543325085746> Excellent" : newPing < 150 ? "<a:yellow_dot:1438002750297210979> Stable" : "<a:RedDot:1438002450085707846> High";

        const refreshed = new ContainerBuilder()

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(`#  GlimpZ — Live Stats (Refreshed)`)

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(

              `<:emoji_54:1435581730114375683> Memory Usage: \`${newMemory} MB\`\n` +

                `<:emoji_54:1435581730114375683> Ping: \`${newPing}ms\`\n` +

                `<:emoji_54:1435581730114375683> Health: **${newHealth}**`

            )

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(

              `<:emoji_54:1435581730114375683> *Auto-optimized by GlimpZ System v3.5*`

            )

          );

        await interaction.update({

          components: [refreshed],

          flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

        });

      }

      if (interaction.customId === "back_about") {

        await interaction.reply({

          content: "Use `!about` to return to the overview panel.",

          ephemeral: true

        });

      }

    });

  }

};