const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
const emojis = require('../emojis.json');

module.exports = {
    name: 'volume',
    aliases: ['vol'],
    description: 'Set music volume',

    async execute(message, args) {
        try {
            const { client, member, guild } = message;

            // ✅ Check if user is in a VC
            const userChannel = member.voice.channel;
            if (!userChannel) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} You need to be in a voice channel!`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }

            // ✅ Check if bot has a player
            const player = client.poru.players.get(guild.id);
            if (!player) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} No music is currently playing!`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }

            // ✅ Check if bot is in same VC
            const botChannelId = player.voiceChannel;
            if (botChannelId && userChannel.id !== botChannelId) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} You must be in the same voice channel as the bot!\n🎵 I am currently in: <#${botChannelId}>`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }

            // ✅ Remove overstrict permission check
            // You had `hasControlPermission` earlier — removing it entirely, 
            // because we only care if they’re in the same VC.
            // If you still want to keep it for owner/admin, uncomment below:
            /*
            const { hasControlPermission } = require('../helpers/musicHelpers');
            if (!hasControlPermission(message, player)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} Only the requester or admins can control the music!`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }
            */

            // ✅ Validate volume argument
            if (!args[0]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} Please provide a volume level (1-100)!`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }

            const level = parseInt(args[0]);
            if (isNaN(level) || level < 1 || level > 100) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${emojis.error} Volume must be between 1 and 100!`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
            }

            // ✅ Apply volume
            player.setVolume(level);

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${emojis.volume} Volume set to **${level}**.`)
                );

            return message.reply({ components: [container], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });

        } catch (err) {
            console.error("Volume Command Error:", err);
            const errorContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${emojis.error} Something went wrong while setting volume.`)
                );
            return message.reply({ components: [errorContainer], flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2 });
        }
    },
};