const {

  ContainerBuilder,

  TextDisplayBuilder,

  SeparatorBuilder,

  SeparatorSpacingSize,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  MessageFlags,

  ComponentType

} = require("discord.js");

module.exports = {

  name: "about",

  description: "Displays detailed information about Nexo Music System",

  async execute(message) {

    const client = message.client;

    // 🔷 Base Container

    const container = new ContainerBuilder()

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(`# <:emoji_59:1435292631247749191> Nexo Music System v3.5`)

      )

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(`> Futuristic • Adaptive • Intelligent `)

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:emoji_54:1435581730114375683> **Nexo** — Next-gen high-fidelity Discord music bot.\n` +

            `<:emoji_54:1435581730114375683> Experience intelligent playback, adaptive filters & seamless Spotify/YouTube integration.\n\n` +

            `> <:emoji_54:1435581730114375683> “Music isn’t just sound — it’s precision in motion.”`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:stats:1437996604702588980> **System Overview**\n` +

            `<:emoji_54:1435581730114375683> Servers: ${client.guilds.cache.size}\n` +

            `<:emoji_54:1435581730114375683> Users: ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()}\n` +

            `<:emoji_54:1435581730114375683> Uptime: ${(client.uptime / 3600000).toFixed(1)}h\n` +

            `<:emoji_54:1435581730114375683> Ping: ${client.ws.ping}ms`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:bots:1437996884131188898> **AI & Audio Engine**\n` +

            `<:emoji_54:1435581730114375683> AutoFilter™ — Smart EQ by genre\n` +

            `<:emoji_54:1435581730114375683> AutoPlay+™ — AI queue continuation\n` +

            `<:emoji_54:1435581730114375683> SmartVolume — Adaptive loudness\n` +

            `<:emoji_54:1435581730114375683> Zero-Lag Lavalink mesh system`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:Settings:1437997041287696394> **Tech Stack**\n` +

            `<:emoji_54:1435581730114375683> Node.js 20+\n` +

            `<:emoji_54:1435581730114375683> Discord.js v14\n` +

            `<:emoji_54:1435581730114375683> Lavalink v4\n` +

            `<:emoji_54:1435581730114375683> SQLite + MongoDB`

        )

      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

      .addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `<:emoji_54:1435581730114375683> *Developed With ❤️ By Team Nexo*\n` +

            `<:emoji_54:1435581730114375683> *Engineered by Nexon Ai*`

        )

      );

    // 🧩 Buttons

    const buttons = new ActionRowBuilder().addComponents(

      new ButtonBuilder()

        .setCustomId("about_more")

        .setLabel(" More Info")

        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()

        .setLabel(" Invite Bot")

        .setStyle(ButtonStyle.Link)

        .setURL(

          `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=303600576574&scope=bot%20applications.commands`

        ),

      new ButtonBuilder()

        .setLabel(" Support Server")

        .setStyle(ButtonStyle.Link)

        .setURL("https://discord.gg/2mM2M5NzVD")

    );

    container.addActionRowComponents(buttons);

    const reply = await message.reply({

      components: [container],

      flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2,

      fetchReply: true

    });

    // 🎯 Interaction Collector

    const collector = reply.createMessageComponentCollector({

      componentType: ComponentType.Button,

      time: 0

    });

    collector.on("collect", async (interaction) => {

      if (interaction.user.id !== message.author.id)

        return interaction.reply({

          content: "❌ Only the user who executed the command can interact.",

          ephemeral: true

        });

      // --- More Info Panel ---

      if (interaction.customId === "about_more") {

        const infoContainer = new ContainerBuilder()

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(`# <:emoji_59:1435292631247749191> GlimpZ — Deep System Information`)

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(

              `<:Modules:1437997368187289680> **Internal Modules**\n` +

                `<:emoji_54:1435581730114375683> Poru Lavalink Handler\n` +

                `<:emoji_54:1435581730114375683> MusicQueue System\n` +

                `<:emoji_54:1435581730114375683> Container UI Core\n` +

                `<:emoji_54:1435581730114375683> Dynamic Prefix Engine`

            )

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(

              `<:storage:1437997529659609118> **Capabilities**\n` +

                `<:emoji_54:1435581730114375683> Real-time stream sync\n` +

                `<:emoji_54:1435581730114375683> Queue persistence\n` +

                `<:emoji_54:1435581730114375683> Adaptive prefix system\n` +

                `<:emoji_54:1435581730114375683> Intelligent filter handling`

            )

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))

          .addTextDisplayComponents(

            new TextDisplayBuilder().setContent(

              `<:036framework:1437997631262687275> **Frameworks Used**\n` +

                `<:emoji_54:1435581730114375683> Node.js 20.11.1\n` +

                `<:emoji_54:1435581730114375683> Discord.js v14.15\n` +

                `<:emoji_54:1435581730114375683> Aiosqlite\n` +

                `<:emoji_54:1435581730114375683> Custom Container Core`

            )

          )

          .addSeparatorComponents(new SeparatorBuilder().setDivider(true));

        // 🔙 Back Button

        const backButton = new ActionRowBuilder().addComponents(

          new ButtonBuilder()

            .setCustomId("about_back")

            .setLabel(" Back to Overview")

            .setStyle(ButtonStyle.Secondary),

          new ButtonBuilder()

            .setLabel(" Vote GlimpZ")

            .setStyle(ButtonStyle.Link)

            .setURL(`https://top.gg/bot/${client.user.id}/vote`)

        );

        infoContainer.addActionRowComponents(backButton);

        await interaction.update({

          components: [infoContainer],

          flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

        });

      }

      // 🔙 Back to main page

      if (interaction.customId === "about_back") {

        await interaction.update({

          components: [container],

          flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

        });

      }

    });

  }

};