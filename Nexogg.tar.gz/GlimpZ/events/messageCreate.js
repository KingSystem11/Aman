const {

  Events,

  ContainerBuilder,

  TextDisplayBuilder,

  SeparatorBuilder,

  SeparatorSpacingSize,

  MessageFlags,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle

} = require("discord.js");

const { getGuildPrefix } = require("../index"); // ✅ Make sure prefix manager is exported properly

const taglines = [

  "Elevate your server's vibe ",

  "Your beats. Your way. ",

  "Powered by passion, driven by sound ",

  "Nexo — redefining Discord music ",

  "Unleash your sound with Nexo "

];

module.exports = {

  name: Events.MessageCreate,

  async execute(message, client) {

    if (message.author.bot || !message.guild) return;

    const mention1 = `<@${client.user.id}>`;

    const mention2 = `<@!${client.user.id}>`;

    const content = message.content.trim();

    // ✅ Trigger only when bot is mentioned directly (not replies or mixed text)

    if (

      (content === mention1 || content === mention2) &&

      !message.reference

    ) {

      const prefix = getGuildPrefix

        ? getGuildPrefix(message.guild.id)

        : ".";

      const container = new ContainerBuilder();

      // 💬 Main Header

      container.addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `# <:emoji_59:1435292631247749191> **Hey, ${message.author.username}!**\nI'm **${client.user.username}**, your musical companion in **${message.guild.name}**!`

        )

      );

      // 🎨 Soft divider

      container.addSeparatorComponents(

        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)

      );

      // ✨ Random tagline

      const tagline = taglines[Math.floor(Math.random() * taglines.length)];

      // 🧠 Core Info

      container.addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `> <:emoji_54:1435581730114375683> ${tagline}\n\n` +

            `**<:emoji_54:1435581730114375683> Prefix:** \`${prefix}\`\n` +

            `**<:emoji_54:1435581730114375683> Get Started:** Try \`${prefix}play <song>\`\n` +

            `**<:emoji_54:1435581730114375683> Help:** Use \`${prefix}help\` to explore features\n` +

            `**<:emoji_54:1435581730114375683> Change Prefix:** \`${prefix}setprefix <new>\``

        )

      );

      container.addSeparatorComponents(

        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)

      );

      // 🎟️ Action Buttons

      const buttons = new ActionRowBuilder().addComponents(

        new ButtonBuilder()

          .setLabel(" Invite Bot")

          .setStyle(ButtonStyle.Link)

          .setURL(

            `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`

          ),

        new ButtonBuilder()

          .setLabel(" Support Server")

          .setStyle(ButtonStyle.Link)

          .setURL("https://discord.gg/2mM2M5NzVD"),

        new ButtonBuilder()

          .setLabel(" Vote Me")

          .setStyle(ButtonStyle.Link)

          .setURL(`https://top.gg/bot/${client.user.id}/vote`)

      );

      container.addActionRowComponents(buttons);

      container.addSeparatorComponents(

        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)

      );

      // 🧩 Footer

      container.addTextDisplayComponents(

        new TextDisplayBuilder().setContent(

          `Developed with ❤️ by **Team Nexo**\nUptime: **${Math.floor(client.uptime / 60000)} mins**`

        )

      );

      await message.reply({

        components: [container],

        flags: MessageFlags.IsPersistent | MessageFlags.IsComponentsV2

      });

    }

  }

};