
module.exports = {
    BOT_TOKEN: process.env.BOT_TOKEN || 'MTQ0OTIwNzY0Nzk2OTczODkxMg.GiZV8H.NelJIyeUVUmZvDuSC5PkuWP7i6SeED1u4CJ7SE',
    CLIENT_ID: process.env.CLIENT_ID || '1381925870813450371',
    OWNER_ID: process.env.OWNER_ID || '1113808268960206928',
    PREFIX: '!',
    
    
    LAVALINK: {
        HOSTS: process.env.LAVALINK_HOSTS || 'lava-v4.ajieblogs.eu.org',
        PORTS: process.env.LAVALINK_PORTS || '443',
        PASSWORDS: process.env.LAVALINK_PASSWORDS ||'https://dsc.gg/ajidevserver',
        SECURES: process.env.LAVALINK_SECURES || 'true'
    },
    
    
    MUSIC: {
        DEFAULT_PLATFORM: 'ytsearch',
        AUTOCOMPLETE_LIMIT: 5,
        PLAYLIST_LIMIT: 3,
        ARTWORK_STYLE: 'MusicCard' // 'Banner' for MediaGallery or 'MusicCard' for custom image card
    },
    
    
    SPOTIFY: {
        CLIENT_ID: process.env.SPOTIFY_CLIENT_ID || 'a568b55af1d940aca52ea8fe02f0d93b',
        CLIENT_SECRET: process.env.SPOTIFY_CLIENT_SECRET || 'e8199f4024fe49c5b22ea9a3dd0c4789'
    },
    
    
    GENIUS: {
        API_KEY: process.env.GENIUS_API_KEY || 'f"https://api.genius.com/search?q={keyword}"'
    }
};

/*
: ! Aegis !
    + Discord: KingSystem11@
    + Community: https://discord.gg/DHfZAycmC  (KingSystem11 Development ) 
*/